package com.axaet.login.common;

/**
 * date: 2019/3/7
 *
 * @author yuShu
 */
public class ARouterURL {


    public static final String LOGIN_MAIN =  "/login/MainActivity";
}
