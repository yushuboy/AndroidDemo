package com.axaet.butterknife.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.alibaba.android.arouter.core.LogisticsCenter;
import com.alibaba.android.arouter.facade.Postcard;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.alibaba.android.arouter.launcher.ARouter;
import com.axaet.butterknife.R;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * @author android
 */
@Route(path = "/main/MainActivity")
public class MainActivity extends AppCompatActivity {


    public static final int REQUEST_CODE = 0x01;
    private static final String URL = "/login/LoginActivity";
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            String result = data.getStringExtra("result");
            Log.i(TAG, "onActivityResult: " + result);
        }
    }

    @OnClick({R.id.btnShow, R.id.button})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btnShow:
                Postcard postcard = ARouter.getInstance().build(URL);
                LogisticsCenter.completion(postcard);
                Class<?> destination = postcard.getDestination();
                Log.i(TAG, destination.getName());
                startActivityForResult(new Intent(this, destination), REQUEST_CODE);
                break;
            case R.id.button:
                ARouter.getInstance().build("/news/MainActivity")
                        .navigation();
                break;
            default:
        }
    }
}
